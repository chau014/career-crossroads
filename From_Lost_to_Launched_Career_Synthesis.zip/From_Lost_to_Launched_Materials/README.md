# From Lost to Launched

SS3724 Positive Psychology · Week 4 · Career Crossroads: One Week to Graduation

## Start the RPG

Extract the ZIP and open Career_Crossroads_Game/index.html in a desktop browser. Keep the game folder and its locales subfolder together. Choose English or Hong Kong Traditional Chinese on the start screen. Use How to play to practise, or skip straight to the story. Settings lets you switch language, replay the tutorial, pause or restart. Use WASD or the arrow keys to walk, E to interact, J for the journal and Esc for Pause. You can also click a marked object or character to walk to it. On a touch screen, use the directional buttons. Pause includes Restart week. The game runs offline with no account, analytics or storage. The original sprite patterns are in art.js, with scenery drawn by the Canvas renderer. Language files are in locales/. Map and route data are in scenarios.js, dialogue and quest text in story.js, and movement and state in script.js.

## Example playthroughs

Read the campus phone and application. Find at least one work clue, then review the café vacancy board and use the planning table. Reading, moving and ordinary advice are free. Completing an optional quest costs one of two slots after confirmation.

| Approach | Example route |
| --- | --- |
| Independent investigation | Inspect the survey log in the dissertation folder. Compare it with the vacancy requirements. Keep the community goal after the deadline closes and use the survey checks in the final draft. |
| Classmate and academic support | Ask Ming for the contribution record. Ask Dr Chan about data checks and the briefing. Pair the briefing with Ming’s record to support a communication claim, or use Dr Chan’s feedback to make a CV statement more specific. |
| Career Advisor support | Ask Yan to compare paid evaluation and outreach roles. If work hours matter, compare the hours at the vacancy board, then carry that comparison into the final action for the communications route. |
| Investigate a limitation | Read the detailed research vacancy at the board or ask the recruiter after discussing alternatives with Yan. It requires independent interviews. At the planning table, clarify what counts as experience, compare paid evaluation support instead, or change direction. Complete one corresponding draft action. |

A survey log supports data checking. A briefing draft and contribution record together support a personal communication claim. Dr Chan’s feedback unlocks a more specific CV option. Choose one approach per draft. If evidence is incomplete, revise the choice, gather more evidence, or draft a question to check the requirements. No individual NPC is required.

## Week 4 delivery insert

Use this insert alongside the existing facilitator guide. The proposal calls the activity Career Crossroads Web Game and uses Continuation Plan and Closing for its last block. Here the game is an RPG and the closing includes the same If–Then planning. The proposal's timings and participant output govern delivery.

| Activity | Minutes |
| --- | ---: |
| Career Quest Review | 10 |
| Future Work Self Writing | 20 |
| Career Crossroads RPG | 30 |
| Facilitator-led Reflection | 20 |
| Continuation Plan and If–Then Planning | 10 |
| Total | 90 |

Within the 30-minute RPG block, allow about 5 minutes to open the game and demonstrate movement and interaction, aim for 15–20 minutes of play, and use the remaining time for transition. The duration is a design target and should be checked with the group. Participants can stop at their current journal state when the activity ends. Use the guide’s existing paper scenarios if devices or controls become a barrier.

During reflection, ask what was known about the rejection, what remained uncertain, and how a revised pathway or goal became workable. Bring in the Week 1 Strengths Evidence Card, Week 2 Hope Map and Week 3 Career Quest Record. Use the final 10 minutes for participants' own Revised Career Action Plan and If–Then planning. Goals provide direction. Pathways and agency are the two core components of Hope Theory. The RPG is a practice activity.

## Package and verification

The participant workbook and facilitator guide are available as editable Word files and printable PDFs. The presentation appendix includes the workbook excerpts, Week 4 fallback and frames rendered by the new game’s Canvas code. Browser Use blocked inspection of the local file URL. The frames are renderer captures rather than browser screenshots. Live browser layout and wrapping, touch interaction, first-time player usability and play duration remain unverified. The simulations also covered tutorial completion and skip, objective progression, and preserving inventory and activity slots when changing language mid-game.

Ten simulated playthroughs covered all three endings in both languages, including independent evidence, classmate and academic support, Yan’s comparison, and both responses to the interviewing requirement. They also checked incomplete evidence and revision, slot spending, inventory, language switching, ending summaries, reflection, and replay.

## 繁體中文（香港）玩法

解壓縮後，在瀏覽器開啟 Career_Crossroads_Game/index.html。保留遊戲資料夾及 locales 子資料夾。開始畫面預設為香港繁體中文，可改用英文。「玩法教學」可重玩或跳過，「設定」可切換語言而保留進度。

用 WASD 或方向鍵移動，按 E 互動，按 J 開啟日誌，按 Esc 開啟設定。亦可點擊地圖上的人物或物件，或用畫面上的箭嘴移動。留意畫面上方的目前任務及地圖上的金色標記。探索、交談、閱讀和教學都不扣額外活動機會。每局最多完成兩項額外活動，確認完成時才扣一次。最後的主線行動毋須扣次數。遊戲完結後，請用工作冊完成反思及修訂職涯行動計劃。

## 線索與選擇

查看問卷核對紀錄，可用資料核對作例子。若想用簡報改寫展示溝通能力，要同時找到簡報草稿及阿明的小組分工紀錄。陳老師的意見可幫你寫出更具體的履歷句子。Yan 可協助比較有薪評估支援及外展工作。詳細研究職位要求獨立訪談經驗，你可以草擬查詢、轉看有薪評估支援職位，或重新考慮其他方向。

每份草稿只需選一個做法。證據不足時，可改選、繼續調查，或寫下想確認的職位要求。一般求助和調查不扣次數。

## Career Action Summary and group discussion

Read the mission briefing on the start screen. Finish one draft action to reach the ending scene, then open Career Action Summary. It shows your original and revised plans, the setbacks and clues you encountered, any conversations or optional work you completed, and a possible next step. Use Copy summary, Save text file, or Print / save PDF. If clipboard access is unavailable, select and copy the text shown in the game.

Continue to Reflection opens three prompts based on your run. Bring them to the existing 20-minute facilitator-led discussion. Use the Week 1 Strengths Evidence Card, Week 2 Career Pathways Hope Map, and Week 3 Career Quest Record to compare the character's choices with your own. Use the separate continuation block to update the Week 4 Revised Career Action Plan and If–Then response.

## 職涯行動結算與小組討論

先閱讀任務簡介。完成一項草稿行動後，開啟「職涯行動結算」，查看你實際遇到的阻礙、找到的線索、交談紀錄、調整前後的計劃和下一步。你可以複製、儲存文字檔，或列印及儲存為 PDF。若瀏覽器限制剪貼簿權限，可選取遊戲顯示的文字再複製。

選擇「進入反思」，把這一局的三條提示帶入原有的 20 分鐘小組討論。參考第一週的優勢證據卡、第二週的職涯路徑希望地圖和第三週的職涯任務紀錄，並在其後的行動規劃環節更新第四週的修訂版職涯行動計劃。

This build passed ten simulated runs across the three endings in both languages. Tests checked actual and skipped conversations and tasks, route comparison, personalised prompts, clipboard calls and fallback, download payload, print invocation, and replay. Print pagination and Chinese wrapping require a live browser check.

## Activity results

Confirming an Explore, Build or Connect activity spends one slot and opens its result card. Journal and Inventory reopen the same saved outcome. The Career Action Summary uses five sections: ending, pathway, resources, action and next step, and one discussion prompt. Copy, text download and print use the same synthesis. Open Journal or Inventory for full activity results, and Inventory for conversation records.

完成「探索」、「建構」或「連繫」活動並確認後，會扣一次機會並顯示行動結果。可在日誌或物品欄重看。職涯行動結算會概括結局、路徑、資源、已完成行動和下一步，並提供一條討論問題。複製、下載和列印均使用同一份摘要。可在日誌或物品欄重看完整行動結果，亦可在物品欄重看對話紀錄。

