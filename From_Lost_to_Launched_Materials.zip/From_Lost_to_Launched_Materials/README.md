# From Lost to Launched materials

This package updates the intervention materials for the SS3724 Positive Psychology presentation. It follows the attached **From_Lost_to_Launched_With_Updated_Evaluation.docx** as the authority for session names, activity sequence, timings and programme details. The earlier package and the attached proposal were preserved without edits.

## Files

| File | Use |
| --- | --- |
| `Participant_Workbook.docx` | Editable A4 workbook. Ten pages: four private 20-minute Future Work Self Writing prompts, Strengths Evidence Card, Career Pathways Hope Map, Career Quest Record, Game Reflection Sheet and Revised Career Action Plan. |
| `Participant_Workbook.pdf` | Print-ready copy of the workbook. |
| `Facilitator_Guide_and_Activity_Cards.docx` | Editable 16-page guide with exact weekly timing, facilitation instructions, three fictional station cards, three fictional alumni-style cases, three Quest cards and three paper backup scenarios. |
| `Facilitator_Guide_and_Activity_Cards.pdf` | Print-ready copy of the guide and cards. |
| `Career_Crossroads_Game/index.html` | Open this file in a normal browser to play the local game. Keep all four game files in the same folder. |
| `Career_Crossroads_Game/styles.css` | Responsive visual design. |
| `Career_Crossroads_Game/script.js` | Navigation, branching and reflection logic. |
| `Career_Crossroads_Game/scenarios.js` | Editable scenario text and choices, separate from the game logic. |
| `Presentation_Appendix.pdf` | Five landscape appendix slides. Enlarged crops of the actual Hope Map and Quest Record, the Week 4 guide and paper fallback, plus two user-supplied captures of the local game's decision and reflection interfaces. |

## Running the game

Double-click `Career_Crossroads_Game/index.html` or open it from a browser's File menu. No server, paid API, account or installation is required. The game uses local HTML, CSS and JavaScript. It makes no network requests and does not save participant choices or notes. Printing a reflection is optional; refresh or close the page to clear the current state.

The game offers three fictional situations: an application rejection, a desired role with an experience gap, and an unexpected opportunity outside Plan A. Each follows **Recognise → Reappraise → Revise → Respond**. Recognise choices change the next Reappraise situation and available responses; Revise choices change the Respond situation and available responses. Changing an earlier choice clears later choices so the reflection stays consistent. All routes have practical trade-offs, with no score or guaranteed employment outcome. Unpaid work or extra spending is never treated as the preferred route. Participants may skip a scenario.

## Programme use

One trained facilitator and one assistant deliver one closed group of approximately seven participants. For pair work with seven people, use two pairs and one trio. Each of the four weekly sessions lasts exactly 90 minutes and includes 20 minutes of private Future Work Self Writing: 2 minutes to settle and read, 15 minutes to write, and 3 minutes to highlight a point.

Snyder's Hope Theory is the single main framework. Meaningful goals give direction; pathways and agency are its two core cognitive components. The worksheets and game are intervention tools, **not** validated measures. Career anxiety and state hope would require separate evaluation with appropriate measures and design. The fictional cards are teaching examples, not genuine alumni records or verified job postings. For Week 3 Explore, the facilitator should provide access to two genuine current job advertisements; fictional station cards are only a fallback practice example.

## Quality checks and limits

- Both DOCX files were reopened successfully and their ZIP containers passed integrity checks.
- Both PDFs were rendered and visually inspected. The workbook is ten A4 pages with writing lines and labelled response areas. The appendix was rendered and inspected.
- All four session schedules were checked programmatically: **90 minutes per week**, including **20 minutes of writing** every week.
- Game JavaScript passed syntax checks. A simulated DOM test exercised all **108 complete branching paths** and **432 choice transitions**, and checked Back, Restart, Skip, Reflection and invalidation of later choices after changing an earlier one. Static inspection found no network or browser storage API calls.
- The updated appendix was rendered and visually inspected. Its game slides show actual local-game captures supplied by the user; they show the shared decision and reflection interface, while branching behaviour was checked by the simulated DOM test.
- The in-app browser security gate blocked access to the local `file:` URL and barred alternate browser routes. A live browser navigation or mobile visual test could not be completed here. The CSS includes responsive layouts at 850 px and 560 px. Native Word pagination also could not be checked. The PDFs are the checked print versions; review the editable DOCX files in Word before classroom printing if local Word pagination differs.
