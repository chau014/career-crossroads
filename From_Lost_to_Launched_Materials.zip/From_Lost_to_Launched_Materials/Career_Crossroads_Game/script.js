(() => {
  'use strict';
  const scenarios=window.CAREER_SCENARIOS;
  const stageNames=['Recognise','Reappraise','Revise','Respond'];
  const el=id=>document.getElementById(id);
  const state={scenario:null,stage:0,choices:[null,null,null,null]};
  function stageFor(index){
    const s=scenarios[state.scenario],base=s.stages[index];
    const previous=state.choices[index-1];
    const variant=previous===null?null:window.CAREER_BRANCHES?.[s.id]?.[index]?.[previous];
    return variant?{...base,...variant}:base;
  }
  function view(name){for(const id of ['home','play','summary'])el(id).classList.toggle('hidden',id!==name);window.scrollTo(0,0)}
  function reset(){state.scenario=null;state.stage=0;state.choices=[null,null,null,null];view('home')}
  function start(index){state.scenario=index;state.stage=0;state.choices=[null,null,null,null];render();view('play')}
  function buttonChoice(choice,index){
    const b=document.createElement('button');b.type='button';b.className='choice';
    if(state.choices[state.stage]===index)b.classList.add('selected');
    b.setAttribute('aria-pressed',String(state.choices[state.stage]===index));
    const title=document.createElement('strong');title.textContent=choice.title;
    const detail=document.createElement('span');detail.textContent=choice.detail;b.append(title,detail);
    b.addEventListener('click',()=>{
      if(state.choices[state.stage]!==index){
        state.choices[state.stage]=index;
        for(let i=state.stage+1;i<state.choices.length;i++)state.choices[i]=null;
      }
      render();
    });return b;
  }
  function render(){
    const s=scenarios[state.scenario],stage=stageFor(state.stage),choiceIndex=state.choices[state.stage];
    el('scenario-tag').textContent=s.tag;el('scenario-title').textContent=s.title;
    el('step-label').textContent=stageNames[state.stage];el('step-count').textContent=`Step ${state.stage+1} of 4`;
    el('progress').setAttribute('aria-valuenow',String(state.stage+1));el('progress-bar').style.width=`${(state.stage+1)*25}%`;
    el('situation').textContent=stage.situation||s.intro;el('goal-reminder').textContent=s.goal;el('question').textContent=stage.question;
    const prior=state.stage>0?state.choices[state.stage-1]:null;
    el('previous').classList.toggle('hidden',prior===null);
    if(prior!==null)el('previous-text').textContent=stageFor(state.stage-1).choices[prior].consequence;
    const box=el('choices');box.replaceChildren(...stage.choices.map(buttonChoice));
    el('consequence').classList.toggle('hidden',choiceIndex===null);
    if(choiceIndex!==null){const c=stage.choices[choiceIndex];el('consequence-text').textContent=c.consequence;el('tradeoff-text').textContent='Trade-off: '+c.tradeoff}
    el('continue').disabled=choiceIndex===null;el('continue').textContent=state.stage===3?'See reflection':'Continue';
    el('back').textContent=state.stage===0?'Choose scenario':'Back';
  }
  function summary(){
    const s=scenarios[state.scenario];el('summary-title').textContent=s.title;
    const grid=el('summary-grid');grid.replaceChildren();
    const labels=['Setback and interpretation','Facts and assumptions','Alternative pathway','Controllable next action'];
    s.stages.forEach((_,i)=>{
      const stage=stageFor(i);
      const card=document.createElement('div');card.className='summary-item';
      const head=document.createElement('strong');head.textContent=labels[i];
      const body=document.createElement('p');const ix=state.choices[i];
      body.textContent=ix===null?'Not chosen yet. You can return to this step.':stage.choices[ix].title+' — '+stage.choices[ix].consequence;
      card.append(head,body);grid.append(card);
    });
    view('summary');
  }
  scenarios.forEach((s,i)=>{
    const card=document.createElement('article');card.className='scenario-card';
    const n=document.createElement('div');n.className='number';n.textContent=`SCENARIO 0${i+1}`;
    const h=document.createElement('h3');h.textContent=s.title;
    const p=document.createElement('p');p.textContent=s.intro;
    const b=document.createElement('button');b.className='primary';b.textContent='Explore scenario →';b.addEventListener('click',()=>start(i));
    card.append(n,h,p,b);el('scenario-grid').append(card);
  });
  el('continue').addEventListener('click',()=>{if(state.choices[state.stage]===null)return;if(state.stage===3)summary();else{state.stage++;render();window.scrollTo(0,0)}});
  el('back').addEventListener('click',()=>{if(state.stage===0)view('home');else{state.stage--;render()}});
  el('skip').addEventListener('click',()=>{if(state.scenario===null)return;summary()});
  el('reflection').addEventListener('click',summary);
  el('restart-top').addEventListener('click',reset);
  el('summary-back').addEventListener('click',()=>{render();view('play')});
  el('new-scenario').addEventListener('click',reset);
  el('print').addEventListener('click',()=>window.print());
})();
