// Edit this file to change scenario text. No player responses are stored here.
window.CAREER_SCENARIOS = [
  {
    id:'rejection',title:'The rejection email',tag:'Scenario 01 · Internship or graduate job rejection',
    intro:'You receive a rejection for a graduate programme assistant role. The email gives no detailed reason. You met several requirements, and the Hong Kong entry-level market is competitive.',
    goal:'Contribute to accessible community programmes through an entry role.',
    stages:[
      {question:'What do you notice first?',choices:[
        {title:'Name the disappointment',detail:'Give yourself a moment before deciding what the email means.',consequence:'You can read the message without making a rushed decision. The reason for rejection remains unknown.',tradeoff:'A pause helps you think, but it does not reveal what happened in recruitment.'},
        {title:'Check your evidence',detail:'List which requirements you met and which you still need to build.',consequence:'You find two strengths supported by examples and one requirement you could investigate.',tradeoff:'This gives useful information, but the employer may still have chosen someone with different experience.'},
        {title:'Notice the market barrier',detail:'Recognise that a competitive market may affect the outcome.',consequence:'You avoid treating a single rejection as a verdict on your worth.',tradeoff:'Competition is real; it also means your next route needs to be practical.'}]},
      {question:'What facts and assumptions would you separate?',choices:[
        {title:'Ask for feedback once',detail:'A short, respectful request may clarify a gap, if the employer replies.',consequence:'You draft a concise request. No reply is guaranteed, so you also plan another information source.',tradeoff:'This may help, but waiting too long could delay other actions.'},
        {title:'Review the application with an adviser',detail:'Use an available career service to examine the CV and role fit.',consequence:'You identify one CV statement that could show your relevant experience more clearly.',tradeoff:'An adviser cannot know the employer’s actual reason.'},
        {title:'Compare a second genuine advertisement',detail:'Check whether the same requirement recurs in a related role.',consequence:'A second posting suggests a skill to develop, while leaving the exact rejection cause uncertain.',tradeoff:'One more posting is useful evidence, not a full labour-market picture.'}]},
      {question:'How could you revise your pathway while keeping the goal?',choices:[
        {title:'Try a related assistant role',detail:'Look for a smaller entry step with overlapping community tasks.',consequence:'You find a route that could build relevant experience toward the same goal.',tradeoff:'The route may take longer and still depends on available openings.'},
        {title:'Build one evidence sample',detail:'Draft a workshop checklist or participant information sheet.',consequence:'You gain an example of organisation and accessible communication to discuss in future applications.',tradeoff:'A sample helps show skills but does not replace formal experience.'},
        {title:'Seek supervised experience',detail:'Check paid or credited opportunities first, with clear hours and supervision.',consequence:'You identify a possible way to practise facilitation while checking whether it is accessible.',tradeoff:'Suitable opportunities may be limited; unpaid work is not assumed to be feasible.'}]},
      {question:'What manageable next action would you choose?',choices:[
        {title:'Set a 20 minute search',detail:'Compare two current related roles on a chosen date.',consequence:'You leave with a bounded action and a question about real requirements.',tradeoff:'You may find few openings; that would be information for revising the route.'},
        {title:'Revise one CV bullet',detail:'Show one actual action and result from a relevant experience.',consequence:'You create a concrete improvement you can use in later applications.',tradeoff:'A stronger bullet improves clarity but cannot guarantee an interview.'},
        {title:'Book a career support conversation',detail:'Bring the ad and one specific question to an adviser.',consequence:'You prepare a focused request for help.',tradeoff:'Appointments may not be immediate; you can still take another small step meanwhile.'}]}
    ]
  },
  {
    id:'requirements',title:'The experience gap',tag:'Scenario 02 · Desired job requirements',
    intro:'A desired NGO programme role asks for experience leading groups. You have planned student activities and supported events, but have had little direct facilitation practice.',
    goal:'Help design and deliver useful community activities.',
    stages:[
      {question:'What is your first interpretation?',choices:[
        {title:'Notice uncertainty',detail:'You do not yet know whether facilitation is essential or preferred.',consequence:'You keep the requirement as a question to verify rather than a final answer.',tradeoff:'You still need current information before applying.'},
        {title:'Name the strength you do have',detail:'Planning events may transfer to programme support.',consequence:'You identify relevant evidence without pretending it is the same as leading groups.',tradeoff:'Transferable experience may not meet every requirement.'},
        {title:'Notice the access issue',detail:'Training or unpaid placements may be hard to fit around finances and time.',consequence:'You treat practical constraints as real conditions for a feasible route.',tradeoff:'You may need to choose a slower or different route.'}]},
      {question:'Which question would improve your understanding?',choices:[
        {title:'Check the exact wording',detail:'Compare “required” and “preferred” in a genuine current ad.',consequence:'You see which criteria are clear and which need clarification.',tradeoff:'Ad wording does not tell you how an employer weighs applicants.'},
        {title:'Ask what counts as experience',detail:'A career adviser may help translate student leadership into evidence.',consequence:'You prepare examples of what you actually did.',tradeoff:'The adviser cannot promise that an employer will count them.'},
        {title:'Compare similar entry roles',detail:'Look at two assistant roles with different levels of facilitation.',consequence:'You find a possible stepping-stone role.',tradeoff:'Availability and pay may differ across roles.'}]},
      {question:'Which alternative route could serve the same goal?',choices:[
        {title:'Supervised practice',detail:'Seek a short, supported opportunity to co-facilitate.',consequence:'You identify a way to learn with feedback and safeguards.',tradeoff:'Access and time may be limiting.'},
        {title:'Programme operations first',detail:'Use planning and record-keeping strengths in an assistant role.',consequence:'You choose a route that uses current evidence and may build proximity to facilitation.',tradeoff:'It may not lead automatically to a facilitator role.'},
        {title:'Skill workshop plus sample',detail:'Take a suitable workshop and draft a session plan.',consequence:'You can demonstrate preparation and identify what still needs practice.',tradeoff:'A workshop and sample are not the same as real group experience.'}]},
      {question:'What would you do in the next seven days?',choices:[
        {title:'Verify one current requirement',detail:'Find a genuine current posting and note the exact wording.',consequence:'You replace a vague worry with a specific fact to work from.',tradeoff:'The requirement could still be difficult to meet.'},
        {title:'Document one relevant event',detail:'Write a CV bullet showing your planning action and outcome.',consequence:'You create stronger evidence for a role that values programme support.',tradeoff:'It still leaves facilitation practice to build.'},
        {title:'Ask about supported practice',detail:'Contact a suitable service or supervisor with two focused questions.',consequence:'You clarify whether a feasible learning opportunity exists.',tradeoff:'Sending is optional, and a reply may take time or not come.'}]}
    ]
  },
  {
    id:'opportunity',title:'The unexpected offer',tag:'Scenario 03 · Opportunity beyond Plan A',
    intro:'A short research support project is offered while your Plan A is community programme work. It might build useful skills, but the hours, pay and supervision are unclear.',
    goal:'Contribute to social impact work that fits your values and practical needs.',
    stages:[
      {question:'What do you notice about this opportunity?',choices:[
        {title:'Interest in learning',detail:'The project may let you test research tasks you enjoyed in class.',consequence:'You identify genuine curiosity as one factor in the decision.',tradeoff:'Interest alone does not settle practical conditions.'},
        {title:'Concern about stability',detail:'A short project may not meet your financial needs.',consequence:'You name a real constraint instead of treating it as lack of motivation.',tradeoff:'You need details before deciding whether it is workable.'},
        {title:'A possible link to Plan A',detail:'Research skills could inform community programme design.',consequence:'You see a potential connection between two routes.',tradeoff:'The link is possible, not guaranteed.'}]},
      {question:'Which facts do you need before interpreting the offer?',choices:[
        {title:'Ask about terms',detail:'Check hours, pay, duration and supervision.',consequence:'You prepare practical questions needed for a sound decision.',tradeoff:'The answers may show the project is not feasible.'},
        {title:'Clarify the work',detail:'Ask what tasks you would actually do and what support is available.',consequence:'You can compare the project with your strengths and learning goals.',tradeoff:'Interesting tasks may still come with inconvenient conditions.'},
        {title:'Check decision timing',detail:'Find out when a response is needed and what other commitments you have.',consequence:'You gain room to compare options without rushing.',tradeoff:'The deadline may be short, so you need to prioritise key questions.'}]},
      {question:'How could you revise pathways while keeping your goal?',choices:[
        {title:'Test research as Plan B',detail:'Treat the project as an experiment while keeping community work in view.',consequence:'You gain a parallel route that might build transferable evidence.',tradeoff:'A short project may require another search soon.'},
        {title:'Protect Plan A time',detail:'Consider the project only if its hours leave room for community applications.',consequence:'You create a condition for trying an alternative without abandoning your preferred direction.',tradeoff:'The employer may not offer the flexibility you need.'},
        {title:'Decline and pursue another route',detail:'If terms do not fit, choose a more feasible support or learning option.',consequence:'You preserve time and resources for a route that better fits your needs.',tradeoff:'You may give up a useful learning opportunity.'}]},
      {question:'What next step would let you decide responsibly?',choices:[
        {title:'Send two questions',detail:'Ask about the most important missing terms before a stated date.',consequence:'You can decide with better information if a reply arrives.',tradeoff:'A late or incomplete reply may require a decision under uncertainty.'},
        {title:'Compare routes on your Hope Map',detail:'Write benefits, constraints and the next step for each route.',consequence:'You make the trade-offs visible and keep your values in view.',tradeoff:'A map supports a decision but cannot remove uncertainty.'},
        {title:'Seek advice with a deadline',detail:'Ask a career adviser or trusted person one focused question.',consequence:'You can add another perspective without handing over your decision.',tradeoff:'Advice may differ, and the choice remains yours.'}]}
    ]
  }
];

// Branches are indexed by destination stage (1 = Reappraise, 3 = Respond)
// and then by the choice made at the immediately preceding stage.
// Each branch changes the next situation and the available responses.
window.CAREER_BRANCHES = {
  rejection: {
    1: [
      {situation:'After taking a pause, you notice that another related paid role closes tomorrow. The rejection reason is still unknown.',question:'How would you use limited time without guessing why you were rejected?',choices:[
        {title:'Check the new role first',detail:'Compare its essential requirements with your evidence before deciding to apply.',consequence:'You find one credible match and one gap, then decide whether a focused application is feasible today.',tradeoff:'A quick check protects time, but a one-day deadline may still be too tight.'},
        {title:'Ask an adviser for a short review',detail:'Bring the rejected application and the new ad, if an appointment is available.',consequence:'You prepare a specific question and a fallback if no appointment is available before the deadline.',tradeoff:'Support may improve clarity, but access to an adviser is not immediate for everyone.'}]},
      {situation:'Your evidence list shows strong event planning examples and limited direct facilitation. The email does not say whether that affected the decision.',question:'Which information would help you interpret this gap fairly?',choices:[
        {title:'Compare current paid assistant roles',detail:'Check whether planning experience is accepted in a related route.',consequence:'You identify one paid entry route that may use your existing evidence.',tradeoff:'Availability and conditions still need checking.'},
        {title:'Review the wording of your CV',detail:'Ask whether the planning work is described clearly and accurately.',consequence:'You find one example that could be made more specific without inventing experience.',tradeoff:'Clearer wording cannot substitute for a requirement you genuinely lack.'}]},
      {situation:'You recognise a competitive market and a need for paid work soon. A longer unpaid placement may be impractical.',question:'What would keep the next route financially realistic?',choices:[
        {title:'Widen to paid adjacent roles',detail:'Compare programme support and outreach assistant vacancies.',consequence:'You identify a broader set of roles that may still connect to your goal.',tradeoff:'A related role may offer less of the work you prefer at first.'},
        {title:'Set a bounded search period',detail:'Keep community roles in view while deciding when to widen further.',consequence:'You create a time limit that protects your resources and leaves room to revise.',tradeoff:'The preferred role may not appear during that period.'}]}
    ],
    3: [
      {situation:'You are considering a related paid assistant role as a step towards community programme work.',question:'Which first action is manageable now?',choices:[
        {title:'Check two current paid ads',detail:'Compare duties, pay and entry requirements on a chosen date.',consequence:'You leave with clearer evidence about whether this route is viable.',tradeoff:'The comparison may show few suitable openings.'},
        {title:'Revise one relevant CV bullet',detail:'Show the strongest real example of programme support.',consequence:'You make a focused application asset without assuming it will lead to an offer.',tradeoff:'The role may still require experience you cannot yet show.'}]},
      {situation:'You want a small work sample that demonstrates a skill without paying for training or taking unpaid work.',question:'What could you make with resources you already have?',choices:[
        {title:'Draft a one-page checklist',detail:'Use a past class or volunteer event as the context.',consequence:'You create a sample that shows planning choices and can invite feedback.',tradeoff:'A sample is evidence of preparation, not direct employment experience.'},
        {title:'Improve an existing class artefact',detail:'Select one section and explain what you changed.',consequence:'You reuse work already completed and make its relevance clearer.',tradeoff:'The artefact may need permission or redaction before sharing.'}]},
      {situation:'You are considering supervised experience, but time and pay need to be workable.',question:'Which step checks feasibility before committing?',choices:[
        {title:'Ask about paid or credited options',detail:'Check hours, supervision and compensation before agreeing.',consequence:'You learn whether the opportunity fits your practical constraints.',tradeoff:'A suitable option may not be available.'},
        {title:'Look for supported tasks in paid roles',detail:'Search for assistant positions that include supervised group work.',consequence:'You keep the learning goal while prioritising paid work.',tradeoff:'Those roles may be competitive or uncommon.'}]}
    ]
  },
  requirements: {
    1: [
      {situation:'The current ad says “group facilitation preferred” in one place and “experience required” in another. The meaning is unclear.',question:'How would you clarify the requirement without assuming the answer?',choices:[
        {title:'Compare a second genuine posting',detail:'Check how similar paid entry roles describe facilitation.',consequence:'You see whether the criterion varies across employers.',tradeoff:'A second ad cannot clarify this employer’s exact rule.'},
        {title:'Ask one concise question',detail:'If a contact is listed, ask whether supported student activity experience counts.',consequence:'You prepare a specific enquiry while keeping another route open.',tradeoff:'The employer may not respond before the closing date.'}]},
      {situation:'You find a real example of planning a student event, including coordination and participant communication, but you did not lead the group.',question:'How could you present that evidence accurately?',choices:[
        {title:'Describe the planning role precisely',detail:'Show actions and outcomes without calling it facilitation.',consequence:'You strengthen your CV while staying truthful about the gap.',tradeoff:'The employer may still prefer direct group-leading experience.'},
        {title:'Ask an adviser to map transferable skills',detail:'Check which parts of your experience fit the role.',consequence:'You identify relevant strengths and a specific learning need.',tradeoff:'Advice does not change the employer’s requirements.'}]},
      {situation:'Your budget and timetable make unpaid practice difficult. You need a route that respects those constraints.',question:'Which information would help you find a feasible path?',choices:[
        {title:'Look for paid trainee or assistant roles',detail:'Check duties and supervision in current advertisements.',consequence:'You identify roles that may combine income with supported learning.',tradeoff:'Suitable positions may be limited.'},
        {title:'Use existing course experience',detail:'Review whether a class or student society project can evidence relevant tasks.',consequence:'You find an example you already have, with no new financial cost.',tradeoff:'It may not fully meet a direct facilitation requirement.'}]}
    ],
    3: [
      {situation:'You are considering supervised practice, but need to avoid a commitment that costs more time or money than you can spare.',question:'What would you check first?',choices:[
        {title:'Ask about pay, credit and hours',detail:'Get the practical terms before deciding.',consequence:'You can judge whether the opportunity is accessible to you.',tradeoff:'It may turn out to be unsuitable.'},
        {title:'Ask about a short paid trial task',detail:'See whether a limited supported task is available.',consequence:'You explore a smaller route to practise and receive feedback.',tradeoff:'The organisation may not offer this arrangement.'}]},
      {situation:'You are considering programme operations as a paid entry route while keeping facilitation as a longer-term goal.',question:'What immediate step fits that route?',choices:[
        {title:'Compare two operations ads',detail:'Check actual duties, pay and progression opportunities.',consequence:'You see how closely the roles connect to your goal.',tradeoff:'Progression is not automatic.'},
        {title:'Revise one CV example',detail:'Show your event planning and record-keeping evidence.',consequence:'You prepare a truthful example for a relevant application.',tradeoff:'One revision cannot overcome all recruitment barriers.'}]},
      {situation:'You are considering a low-cost skills workshop and a sample plan, but neither is the same as live group experience.',question:'What could you do without assuming a certificate will secure work?',choices:[
        {title:'Use a free university session',detail:'Check whether a suitable workshop is available and accessible.',consequence:'You may gain guided practice without extra cost.',tradeoff:'Dates or places may not fit.'},
        {title:'Draft a session outline now',detail:'Use an existing class topic and ask for feedback if possible.',consequence:'You create a small evidence sample and identify a question for future practice.',tradeoff:'The outline still needs real-world testing.'}]}
    ]
  },
  opportunity: {
    1: [
      {situation:'The project asks for a quick answer. You are interested, but you do not yet know the hours or supervision.',question:'Which information is essential before you decide?',choices:[
        {title:'Ask about the terms first',detail:'Request hours, pay, duration and supervision in one concise message.',consequence:'You seek the information needed to judge feasibility.',tradeoff:'The deadline may arrive before every detail is clear.'},
        {title:'Compare the work with your values',detail:'Identify which research tasks connect to your social impact goal.',consequence:'You find a possible reason to consider the project without committing yet.',tradeoff:'Meaningful work still has to fit your financial and time needs.'}]},
      {situation:'You have existing study and paid-work commitments. The short project could create financial pressure if its hours fluctuate.',question:'What would help you judge stability?',choices:[
        {title:'Ask about guaranteed hours and pay',detail:'Check the minimum commitment and payment schedule.',consequence:'You can assess whether the project meets your needs.',tradeoff:'The terms may rule it out.'},
        {title:'Compare your current commitments',detail:'Map the project’s likely hours against work and study.',consequence:'You see where a clash could occur before accepting.',tradeoff:'Some uncertainty may remain until duties are confirmed.'}]},
      {situation:'You see a possible link between research and community programme design, but the project tasks are not yet clear.',question:'How would you test that link?',choices:[
        {title:'Ask what deliverables you would produce',detail:'Find out whether the role offers useful research practice.',consequence:'You can compare concrete tasks with your goal.',tradeoff:'The project may involve less relevant work than expected.'},
        {title:'Ask how findings are used',detail:'Check whether the research informs services or policy.',consequence:'You learn whether the work aligns with your values.',tradeoff:'The connection may be indirect or outside your control.'}]}
    ],
    3: [
      {situation:'You might treat the research project as Plan B while keeping community work in view.',question:'What next action keeps both routes realistic?',choices:[
        {title:'Clarify terms before accepting',detail:'Ask two practical questions by the stated deadline.',consequence:'You can decide with better information if a reply arrives.',tradeoff:'The answers may still leave uncertainty.'},
        {title:'Update your Hope Map',detail:'List what this project could build and what Plan A still needs.',consequence:'You keep the routes distinct and visible.',tradeoff:'A map helps reasoning but does not create an opening.'}]},
      {situation:'You would consider the project only if it leaves time for your existing commitments and Plan A search.',question:'How would you check that condition?',choices:[
        {title:'Ask for a weekly hours range',detail:'Compare it with study, paid work and applications.',consequence:'You can decide whether the schedule is workable.',tradeoff:'Hours may still vary during the project.'},
        {title:'Propose a bounded availability',detail:'State the hours you can offer and ask whether they fit.',consequence:'You protect your time while testing flexibility.',tradeoff:'The project may need a different schedule.'}]},
      {situation:'You may decline the project if its terms do not fit, while continuing towards the same social impact goal.',question:'What would you do next?',choices:[
        {title:'Decline respectfully and continue Plan A',detail:'State your decision and schedule one community-role action.',consequence:'You keep your resources focused on a route that fits better.',tradeoff:'You may miss a useful learning experience.'},
        {title:'Seek a different paid related role',detail:'Compare one current role that fits your time and income needs.',consequence:'You create a parallel route without assuming this project is the only opportunity.',tradeoff:'Another suitable role may take time to find.'}]}
    ]
  }
};
